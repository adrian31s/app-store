/*import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  images = ['./assets/images/be7ccd957d156fa9577b78eb62972b75.jpg', './assets/images/Laptop-ASUS-ROG-Strix-G15-G513QR-1.png', './assets/images/Screenshot_24.png', './assets/images/Screenshot_25.png'];
}
